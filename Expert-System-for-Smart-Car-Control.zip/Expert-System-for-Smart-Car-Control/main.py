from tkinter import *
import tkinter as tk
from tkinter import messagebox

from inference_engine import ie
from knowledge_base import kb


def show_frame(frame):
    frame.tkraise()
window=tk.Tk()
window.title('<Expert system for managing a smart car>')


window.state('zoomed')
window.rowconfigure(0,weight=1)
window.columnconfigure(0,weight=1)

frame1=tk.Frame(window)
frame2=tk.Frame(window)
frame3=tk.Frame(window)
frame4=tk.Frame(window)
frame5=tk.Frame(window)
frame6=tk.Frame(window)
frame7=tk.Frame(window)
frame8=tk.Frame(window)
frame9=tk.Frame(window)
frame10=tk.Frame(window)
frame11=tk.Frame(window)
frameback=tk.Frame(window)
frameEND=tk.Frame(window)



for frame in (frame1,frame2,frame3,frame4,frame5,frame6,frame7,frame8,frame9,frame10,frame11,frameback,frameEND):

    frame.grid(row=0,column=0,sticky='nsew')

#frame-1
frame1_title1=tk.Label(frame1,text='Welcome Mr.Rabbi For Consultation with Expert System',font=('Arial black',30),bg='pink',padx=300, pady=300)
frame1_title2=tk.Label(frame1,text='Would we start from here?',font=('tahoma',25),bg='yellow')

frame1_title1.pack() 
frame1_title2.pack() 

frame1_btn=tk.Button(frame1,text='    YES   ',fg="green",font=('Arial',30),command=lambda:show_frame(frame2))
frame1_btn.pack(side=LEFT)
frame1a_btn=tk.Button(frame1,text='    NO   ',fg="red",font=('Arial',30),command=lambda:show_frame(frameEND))
frame1a_btn.pack(side=RIGHT)

#frame-2
frame2_title=tk.Label(frame2,text=ie['f2'],font=('Arial',30),bg='pink',padx=300, pady=300)

frame2_title.pack(fill='x') 

frame2_btn=tk.Button(frame2,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame3))
frame2_btn.pack(side=LEFT)
frame2a_btn=tk.Button(frame2,text='    NO   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame4))
frame2a_btn.pack(side=RIGHT)






#frame-3
frame3_title=tk.Label(frame3,text=ie['f3'],font=('Arial',30),bg='gray',padx=300, pady=300)

frame3_title.pack(fill='x') 

frame3_btn=tk.Button(frame3,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame4))
frame3_btn.pack(side=LEFT)
frame3a_btn=tk.Button(frame3,text='    NO   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame6))
frame3a_btn.pack(side=RIGHT)



#frame-4
frame4_title=tk.Label(frame4,text=ie['f4'],font=('Arial',30),bg='pink',padx=300, pady=300)

frame4_title.pack(fill='x') 

frame4_btn=tk.Button(frame4,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame5))
frame4_btn.pack(side=LEFT)
frame4a_btn=tk.Button(frame4,text='    NO   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame6))
frame4a_btn.pack(side=RIGHT)




#frame-5
frame5_title=tk.Label(frame5,text=kb['f5'],font=('Arial',30),bg='gray',padx=300, pady=300)

frame5_title.pack(fill='x') 

frame5_btn=tk.Button(frame5,text='    NEXT   ',font=('Arial',30),command=lambda:show_frame(frame7))
frame5_btn.pack(side=BOTTOM)



#frame-6
frame6_title=tk.Label(frame6,text=kb['f6'],font=('Arial',20),bg='pink',padx=200, pady=300)

frame6_title.pack(fill='x') 

frame6_btn=tk.Button(frame6,text='    NEXT  ',font=('Arial',30),command=lambda:show_frame(frame7))
frame6_btn.pack(side=BOTTOM)





#frame-7

frame7_title=tk.Label(frame7,text=ie['f7'],font=('Arial',30),bg='gray',padx=300, pady=300)

frame7_title.pack(fill='x') 

frame7_btn=tk.Button(frame7,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame8))
frame7_btn.pack(side=LEFT)
frame7a_btn=tk.Button(frame7,text='    NO   ',fg="blue",font=('Arial',30),command=lambda:show_frame(frame9))
frame7a_btn.pack(side=RIGHT)


#frame-8

frame8_title=tk.Label(frame8,text=kb['f8'],font=('Arial',30),bg='pink',padx=300, pady=300)

frame8_title.pack(fill='x') 

frame8_btn=tk.Button(frame8,text='    YES   ',font=('Arial',30),command=lambda:show_frame(frameback))
frame8_btn.pack(side=LEFT)
frame8a_btn=tk.Button(frame8,text='    NO   ',font=('Arial',30),command=lambda:show_frame(frameback))
frame8a_btn.pack(side=RIGHT)

#frame-9

frame9_title=tk.Label(frame9,text=kb['f9'],font=('Arial',25),bg='gray',padx=300, pady=300)

frame9_title.pack(fill='x') 

frame9_btn=tk.Button(frame9,text='    NEXT   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame10))
frame9_btn.pack(side=LEFT)


#frame-10

frame10_title=tk.Label(frame10,text=ie['f10'],font=('Arial',10),bg='gray',padx=300, pady=300)

frame10_title.pack(fill='x') 

frame10_btn=tk.Button(frame10,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frame11))
frame10_btn.pack(side=LEFT)
frame10a_btn=tk.Button(frame10,text='    NO   ',fg="violet",font=('Arial',30),command=lambda:show_frame(frameback))
frame10a_btn.pack(side=RIGHT)

#frame-11

frame11_title=tk.Label(frame11,text=kb['f11'],font=('Arial',25),bg='gray',padx=300, pady=300)

frame11_title.pack(fill='x') 

frame11_btn=tk.Button(frame11,text='    YES   ',fg="red",font=('Arial',30),command=lambda:show_frame(frameback))
frame11_btn.pack(side=LEFT)
frame11a_btn=tk.Button(frame11,text='    NO   ',fg="violet",font=('Arial',30),command=lambda:show_frame(frameback))
frame11a_btn.pack(side=RIGHT)
#frame-back

frameback_title=tk.Label(frameback,text='back',font=('Arial',30),bg='pink',padx=300, pady=300)


frameback_title.pack(fill='x') 




#frame-END
frameEND_title=tk.Label(frameEND,text='*** Thanks ***',font=('Arial Black',30),bg='white',padx=300, pady=300)

frameEND_title.pack(fill='x') 

frameEND_btn=tk.Button(frameEND,text='    RESET   ',fg="red",font=('Tahoma',30),command=lambda:show_frame(frame1))
frameEND_btn.pack(side=BOTTOM)





show_frame(frame1)
window.mainloop()
