kb = {
    
    'f5':'Switching operation should be checked',
    'f6':'Contact an experience automobile personnel as the car’s fault/problem might be likely a major electrical problem.',
    'f8':'Change the fuel pump',
    'f9':'Replace the slow running jet with the help of experienced automobile personnel (recommended).',
    'f11':'System would stop the car, open the bonnet and let the engine cools for some time before restarting it.'

    }   