#dictionary---------------------------------------------------------------->>>>>>>>>>>>...


ie = {
    
    'f2':'Is key ignition to start car turned on and engine fails to crank ? ',
    'f3':'Is car still fails to crank ? ',
    'f4':'Is there enough fuel/gas but the engine still fails to crank ? ',
    'f7':'Is slow running jet block for carburettor and lack of fuel supply ? ',
    'f10':'Is the water level and radiator fan are checked which found to be working properly, and is there no radiator leakage, but the temperature of engine remains as high as before causing engine to overheat'
    }   


    
   
           